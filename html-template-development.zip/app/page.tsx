'use client'

import { useState } from 'react'

const products = [
  { title: 'ASTUTE OB55', subtitle: 'Original firmware', tone: 'blue', badge: 'OFFICIAL' },
  { title: 'ASTUTE PRO', subtitle: 'Advanced configuration', tone: 'purple', badge: 'PRO' },
  { title: 'OB55 TOOLKIT', subtitle: 'Utilities & resources', tone: 'cyan', badge: 'TOOLS' },
]

export default function Page() {
  const [message, setMessage] = useState('')

  function showMessage(text: string) {
    setMessage(text)
    window.setTimeout(() => setMessage(''), 2600)
  }

  return (
    <main className="site-shell">
      <div className="container">
        <header className="top">
          <div className="icon" aria-hidden="true"><span>✦</span></div>
          <h1 className="title">ASTUTE OB55</h1>
          <p className="desc">A refined toolkit for your device.<br />Fast, secure, and always up to date.</p>
        </header>

        <section className="stats" aria-label="System status">
          <div><span>STATUS</span><b className="online">● ONLINE</b></div>
          <div><span>VERSION</span><b className="blue">v2.4.1</b></div>
          <div><span>UPDATED</span><b>JUST NOW</b></div>
        </section>
        <div className="filesize">PACKAGE SIZE <strong>24.8 MB</strong></div>

        <section aria-labelledby="releases-heading">
          <p className="label" id="releases-heading">LATEST RELEASES</p>
          {products.map((product) => (
            <article className={`card ${product.tone}`} key={product.title}>
              <div className="card-art" aria-hidden="true"><div className="orb" /><div className="grid-lines" /></div>
              <div className="overlay"><div><b>{product.title}</b><p>{product.subtitle}</p></div><span className="btn-store">{product.badge}</span></div>
            </article>
          ))}
        </section>

        <section aria-labelledby="download-heading">
          <p className="label" id="download-heading">QUICK ACCESS</p>
          <div className="box">
            <div className="box-head"><b><span className="download-icon" aria-hidden="true">↓</span> Download package</b><span className="tag">STABLE</span></div>
            <p>Get the latest verified build for your setup.</p>
            <button className="btn" onClick={() => showMessage('Download queued — your package is ready.')}>Download now <span aria-hidden="true">→</span></button>
          </div>
          <div className="box feature-box">
            <div className="box-head"><b><span className="shield-icon" aria-hidden="true">✓</span> Verified & secure</b><span className="tag">SHA-256</span></div>
            <p>Every release is checked before it reaches you.</p>
          </div>
        </section>

        <footer>ASTUTE OB55 <span>•</span> kaz4RC <span>•</span> 2025</footer>
      </div>
      {message && <div className="toast" role="status">{message}</div>}
    </main>
  )
}
